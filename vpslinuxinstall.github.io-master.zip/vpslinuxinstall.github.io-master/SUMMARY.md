# Table of contents

* [Install software on Linux](README.md)
* [Cloud](cloud-1/README.md)
  * [Kodexplorer](cloud-1/kodexplorer/README.md)
    * [Docker pull](cloud-1/kodexplorer/docker-pull.md)
  * [Pydio](cloud-1/pydio/README.md)
    * [Docker pull](cloud-1/pydio/docker-pull.md)
    * Docker pull-1
  * [filebrowser](cloud-1/cloud/README.md)
    * [Manually Install](cloud-1/cloud/1.manually-install.md)
    * [Manually Install](cloud-1/cloud/untitled.md)
    * [Automatically install](cloud-1/cloud/automatically-install.md)

