# Automatically install

## 3.Automatically install

```bash
wget https://github.com/vpslinuxinstall/Filebrowser/blob/master/filebrowser.sh
chmod +x filebrowser.sh
./filebrowser.sh
```



