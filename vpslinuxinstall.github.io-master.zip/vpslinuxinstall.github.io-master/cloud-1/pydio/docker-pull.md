---
description: Docker pull
---

# Docker pull

### Docker hub

```bash
docker run -d -p 8090:8080 jameseckersall/pydio
```



